<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basit PHP Sayfası</title>
</head>
<body>

    <h2>PHP ile Basit Bir Form</h2>

    <?php
    // Formdan gelen verileri kontrol ediyoruz
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $isim = htmlspecialchars($_POST['isim']);
        $email = htmlspecialchars($_POST['email']);
        
        if (!empty($isim) && !empty($email)) {
            echo "<p>Merhaba, $isim! E-posta adresiniz: $email</p>";
        } else {
            echo "<p>Lütfen tüm alanları doldurun.</p>";
        }
    }
    ?>

    <!-- Basit bir form oluşturuyoruz -->
    <form method="POST" action="">
        <label for="isim">İsim:</label><br>
        <input type="text" id="isim" name="isim"><br><br>

        <label for="email">E-posta:</label><br>
        <input type="email" id="email" name="email"><br><br>

        <input type="submit" value="Gönder">
    </form>

</body>
</html>
